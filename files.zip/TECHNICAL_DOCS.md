# 📚 Ration Card Portal - Complete Technical Documentation

## Table of Contents
1. [Architecture](#architecture)
2. [Database Schema](#database-schema)
3. [API Documentation](#api-documentation)
4. [Frontend Guide](#frontend-guide)
5. [Workflow Explanation](#workflow-explanation)
6. [Security Features](#security-features)
7. [Production Deployment](#production-deployment)

---

## Architecture

### System Architecture Diagram

```
┌─────────────────────────────────────────────────────────┐
│                    CLIENT BROWSER                        │
│  (HTML/CSS/JavaScript - Vanilla, No Framework)          │
└────────────────┬────────────────────────────────────────┘
                 │
                 │ HTTP/AJAX
                 │
┌────────────────▼────────────────────────────────────────┐
│                  NODEJS EXPRESS SERVER                   │
│  ┌──────────────────────────────────────────────────┐   │
│  │  Routes (Auth, Customer, Admin, Print)          │   │
│  │  Controllers & Business Logic                   │   │
│  │  JWT Authentication                             │   │
│  │  PDF Generation (PDFKit)                        │   │
│  └──────────────────────────────────────────────────┘   │
└────────────────┬────────────────────────────────────────┘
                 │
        Mongoose │ ODM
                 │
┌────────────────▼────────────────────────────────────────┐
│              MONGODB DATABASE                            │
│  ┌──────────────┐  ┌──────────────┐  ┌──────────────┐  │
│  │  Customers   │  │    Admins    │  │   PrintReqs  │  │
│  └──────────────┘  └──────────────┘  └──────────────┘  │
└─────────────────────────────────────────────────────────┘

FILE SYSTEM
┌──────────────────────┐
│  /pdfs/ folder       │
│  (Generated PDFs)    │
└──────────────────────┘
```

### Technology Stack

| Component | Technology |
|-----------|-----------|
| Frontend | HTML5, CSS3, Vanilla JavaScript |
| Backend | Node.js, Express.js |
| Database | MongoDB, Mongoose ODM |
| PDF Generation | PDFKit |
| Authentication | JWT (JSON Web Tokens) |
| Password Hashing | bcryptjs |
| Server Port | 5000 (configurable) |

---

## Database Schema

### Customer Collection

```javascript
{
  _id: ObjectId,
  rationCardNumber: String (unique, required),
  fullName: String,
  fatherName: String,
  mothersName: String,
  dateOfBirth: Date,
  gender: String ('Male', 'Female', 'Other'),
  address: String,
  state: String,
  district: String,
  pincode: String,
  mobileNumber: String,
  email: String,
  aadharNumber: String,
  familyMembers: [
    {
      name: String,
      relation: String,
      age: Number
    }
  ],
  status: String ('Active', 'Inactive', 'Cancelled'),
  createdAt: Date,
  updatedAt: Date
}
```

### Admin Collection

```javascript
{
  _id: ObjectId,
  username: String (unique, required),
  email: String (unique, required),
  password: String (hashed),
  fullName: String,
  role: String ('Super Admin', 'Admin', 'Operator'),
  department: String,
  isActive: Boolean,
  createdAt: Date
}
```

### PrintRequest Collection

```javascript
{
  _id: ObjectId,
  tokenNumber: String (unique, required),
  customerId: ObjectId (ref: Customer),
  rationCardNumber: String,
  requestType: String ('Original', 'Duplicate', 'Correction'),
  status: String ('Pending', 'Approved', 'Rejected', 'Printed', 'Collected'),
  printedBy: ObjectId (ref: Admin),
  remarks: String,
  pdfPath: String,
  requestedAt: Date,
  processedAt: Date,
  collectedAt: Date
}
```

---

## API Documentation

### Authentication Endpoints

#### Admin Login
```
POST /api/auth/admin-login

Request Body:
{
  "username": "admin",
  "password": "admin123"
}

Response (Success - 200):
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "admin": {
    "id": "507f1f77bcf86cd799439011",
    "username": "admin",
    "fullName": "Admin User",
    "role": "Super Admin"
  }
}

Response (Error - 401):
{
  "message": "Invalid credentials"
}
```

#### Register Admin (Super Admin Only)
```
POST /api/auth/register-admin

Request Body:
{
  "username": "newadmin",
  "email": "newadmin@example.com",
  "password": "secure123",
  "fullName": "New Admin",
  "role": "Admin"
}

Response (Success - 201):
{
  "message": "Admin created successfully",
  "admin": {
    "id": "507f1f77bcf86cd799439012",
    "username": "newadmin",
    "fullName": "New Admin",
    "role": "Admin"
  }
}
```

### Customer Endpoints

#### Get Customer by Ration Card
```
GET /api/customer/ration/:rationCardNumber

Response (Success - 200):
{
  "success": true,
  "customer": {
    "id": "507f1f77bcf86cd799439011",
    "rationCardNumber": "MH-TEST-001",
    "fullName": "John Doe",
    "fatherName": "Father Name",
    "dateOfBirth": "1990-01-01T00:00:00Z",
    "gender": "Male",
    "address": "123 Main St",
    "district": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400001",
    "mobileNumber": "9876543210",
    "email": "john@example.com",
    "familyMembers": [],
    "status": "Active"
  }
}

Response (Error - 404):
{
  "message": "Ration card not found"
}
```

#### Add New Customer
```
POST /api/customer/add

Request Body:
{
  "rationCardNumber": "MH-TEST-002",
  "fullName": "Jane Doe",
  "fatherName": "Father Name",
  "mothersName": "Mother Name",
  "dateOfBirth": "1992-05-15",
  "gender": "Female",
  "address": "456 Oak Ave",
  "state": "Maharashtra",
  "district": "Pune",
  "pincode": "411001",
  "mobileNumber": "9876543211",
  "email": "jane@example.com",
  "aadharNumber": "1234 5678 9012 3456",
  "familyMembers": [
    {
      "name": "Son Name",
      "relation": "Son",
      "age": 10
    }
  ]
}

Response (Success - 201):
{
  "message": "Customer added successfully",
  "customer": { ... }
}
```

### Print Request Endpoints

#### Create Print Request
```
POST /api/admin/create-print-request

Headers:
{
  "admin-id": "507f1f77bcf86cd799439011"
}

Request Body:
{
  "customerId": "507f1f77bcf86cd799439011",
  "rationCardNumber": "MH-TEST-001",
  "requestType": "Original",
  "remarks": "Customer requested print"
}

Response (Success - 201):
{
  "success": true,
  "message": "Print request created successfully",
  "printRequest": {
    "tokenNumber": "TOK-1702345678-ABC123DEF",
    "rationCardNumber": "MH-TEST-001",
    "status": "Pending",
    "requestType": "Original",
    "requestedAt": "2024-12-11T10:30:00Z"
  }
}
```

#### Get Pending Requests
```
GET /api/admin/pending-requests

Headers:
{
  "Authorization": "Bearer {token}"
}

Response (Success - 200):
{
  "success": true,
  "requests": [
    {
      "_id": "507f1f77bcf86cd799439013",
      "tokenNumber": "TOK-1702345678-ABC123DEF",
      "customerId": {
        "_id": "507f1f77bcf86cd799439011",
        "fullName": "John Doe",
        "rationCardNumber": "MH-TEST-001",
        "mobileNumber": "9876543210"
      },
      "rationCardNumber": "MH-TEST-001",
      "requestType": "Original",
      "status": "Pending",
      "requestedAt": "2024-12-11T10:30:00Z"
    }
  ]
}
```

#### Approve Print Request
```
PUT /api/admin/approve-request/:id

Headers:
{
  "admin-id": "507f1f77bcf86cd799439011"
}

Request Body:
{
  "remarks": "Approved for printing"
}

Response (Success - 200):
{
  "success": true,
  "message": "Request approved",
  "request": { ... }
}
```

### PDF & Download Endpoints

#### Generate PDF
```
POST /api/print/generate-pdf

Request Body:
{
  "tokenNumber": "TOK-1702345678-ABC123DEF",
  "customerId": "507f1f77bcf86cd799439011"
}

Response (Success - 200):
{
  "success": true,
  "message": "PDF generated successfully",
  "downloadUrl": "/api/print/download/TOK-1702345678-ABC123DEF",
  "pdfPath": "TOK-1702345678-ABC123DEF.pdf"
}
```

#### Download PDF
```
GET /api/print/download/:token

Example: GET /api/print/download/TOK-1702345678-ABC123DEF

Response: Binary PDF file download
```

#### Check PDF Status
```
GET /api/print/status/:token

Example: GET /api/print/status/TOK-1702345678-ABC123DEF

Response (Success - 200):
{
  "success": true,
  "tokenNumber": "TOK-1702345678-ABC123DEF",
  "status": "Approved",
  "pdfAvailable": true,
  "requestedAt": "2024-12-11T10:30:00Z",
  "processedAt": "2024-12-11T11:00:00Z"
}
```

---

## Frontend Guide

### Page Structure

#### Customer Portal
```
┌─────────────────────────────────────────┐
│         CUSTOMER PORTAL                 │
├─────────────────────────────────────────┤
│                                         │
│  1. Search Ration Card Section          │
│     - Input field for ration card no.   │
│     - Search button                     │
│                                         │
│  2. Customer Details Display (if found) │
│     - All customer information grid     │
│     - Request Print button              │
│                                         │
│  3. Print History Section               │
│     - List of all print requests        │
│     - Status badges                     │
│                                         │
│  4. Download by Token Section           │
│     - Token input field                 │
│     - Download button                   │
│     - Status display                    │
│                                         │
└─────────────────────────────────────────┘
```

#### Admin Portal
```
┌─────────────────────────────────────────┐
│          ADMIN DASHBOARD                │
├─────────────────────────────────────────┤
│                                         │
│  1. Login Section (if not logged in)    │
│     - Username field                    │
│     - Password field                    │
│     - Login button                      │
│                                         │
│  2. Statistics Cards (after login)      │
│     - Total Requests                    │
│     - Pending, Approved, Printed, etc.  │
│     - Total Customers                   │
│                                         │
│  3. Search Customers Section            │
│     - Search input                      │
│     - Search results                    │
│                                         │
│  4. Pending Print Requests              │
│     - Table with all pending requests   │
│     - Approve/Reject/Generate PDF btn   │
│                                         │
│  5. Create Print Request Section        │
│     - Customer ID input                 │
│     - Ration card input                 │
│     - Request type dropdown             │
│     - Create button                     │
│                                         │
│  6. Add New Customer Section            │
│     - Form with customer details        │
│     - Add button                        │
│                                         │
└─────────────────────────────────────────┘
```

### JavaScript Functions Overview

| Function | Purpose |
|----------|---------|
| `showSection(section)` | Switch between customer and admin tabs |
| `searchRationCard()` | Search customer by ration card number |
| `displayCustomerDetails(customer)` | Show customer info on page |
| `loadPrintHistory(rationCard)` | Load customer's print history |
| `requestPrint()` | Create new print request |
| `downloadByToken()` | Download PDF using token |
| `adminLogin()` | Admin authentication |
| `showAdminDashboard()` | Display admin panel |
| `loadDashboardStats()` | Load dashboard statistics |
| `loadPendingRequests()` | Get and display pending requests |
| `approvePrintRequest(id)` | Approve a print request |
| `rejectPrintRequest(id)` | Reject a print request |
| `generatePDF(token, customerId)` | Generate PDF for a request |
| `adminSearchCustomer()` | Search customers (admin) |
| `addNewCustomer()` | Add customer to database |

---

## Workflow Explanation

### Customer Print Request Workflow

```
Step 1: Customer searches ration card
   └─> API: GET /api/customer/ration/:cardNo
       └─> Shows customer details

Step 2: Customer clicks "Request Print"
   └─> API: POST /api/admin/create-print-request
       └─> Creates PrintRequest document
           └─> Generates unique token
               └─> Status: "Pending"

Step 3: Admin sees pending request on dashboard
   └─> API: GET /api/admin/pending-requests
       └─> Shows all pending requests

Step 4: Admin clicks "Approve"
   └─> API: PUT /api/admin/approve-request/:id
       └─> Updates status to "Approved"

Step 5: Admin clicks "Generate PDF"
   └─> API: POST /api/print/generate-pdf
       └─> Generates PDF with customer details
           └─> Saves to /pdfs folder
               └─> Updates status to "Approved"

Step 6: Customer uses token to download
   └─> API: GET /api/print/status/:token (check status)
       └─> API: GET /api/print/download/:token (download)
           └─> PDF downloads to computer

Step 7: Admin marks as "Printed" and "Collected"
   └─> API: PUT /api/admin/mark-printed/:id
   └─> API: PUT /api/admin/mark-collected/:id
       └─> Workflow complete
```

---

## Security Features

### Implemented Security Measures

✅ **Password Hashing**
- All admin passwords hashed with bcryptjs (10 rounds)
- Never store plaintext passwords

✅ **JWT Authentication**
- Admin tokens expire in 24 hours
- Token verified on protected routes
- Token stored in localStorage

✅ **Input Validation**
- All form inputs validated
- Invalid data rejected
- Error messages shown to user

✅ **Database Validation**
- Mongoose schema validation
- Unique constraint on ration card numbers
- Required fields enforced

✅ **CORS Protection**
- CORS configured on backend
- Only specified origins allowed

✅ **Error Handling**
- Errors logged, not exposed to frontend
- User-friendly error messages
- No sensitive info in responses

### Security Best Practices

⚠️ **For Production:**
1. Change default admin credentials
2. Use strong JWT_SECRET (min 32 characters)
3. Enable HTTPS/SSL
4. Use environment variables for all secrets
5. Implement rate limiting
6. Add request logging
7. Regular security audits
8. Use MongoDB encryption
9. Backup database regularly
10. Implement role-based access control

---

## Production Deployment

### Environment Setup

```env
# .env (Production)
PORT=5000
MONGODB_URI=mongodb+srv://user:pass@cluster.mongodb.net/ration-prod
JWT_SECRET=your-very-long-secret-key-32-chars-minimum
NODE_ENV=production
```

### Docker Deployment

**Dockerfile:**
```dockerfile
FROM node:16-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 5000
CMD ["node", "server.js"]
```

**docker-compose.yml:**
```yaml
version: '3.8'
services:
  app:
    build: .
    ports:
      - "5000:5000"
    environment:
      MONGODB_URI: mongodb://mongo:27017/ration-portal
      JWT_SECRET: ${JWT_SECRET}
    depends_on:
      - mongo
  mongo:
    image: mongo:5
    volumes:
      - mongo_data:/data/db
volumes:
  mongo_data:
```

### Heroku Deployment

**Procfile:**
```
web: node server.js
```

**Deploy:**
```bash
heroku login
heroku create your-app-name
git push heroku main
```

### SSL/HTTPS Setup

Use Nginx as reverse proxy:
```nginx
server {
  listen 443 ssl http2;
  server_name yourdomain.com;
  
  ssl_certificate /etc/ssl/certs/cert.pem;
  ssl_certificate_key /etc/ssl/private/key.pem;
  
  location / {
    proxy_pass http://localhost:5000;
    proxy_set_header Host $host;
    proxy_set_header X-Real-IP $remote_addr;
  }
}
```

---

## Monitoring & Maintenance

### Logs to Monitor
- Admin login attempts
- Failed authentication
- PDF generation errors
- Database connection issues
- Unhandled exceptions

### Database Maintenance
- Regular backups (daily)
- Index optimization
- Collection cleanup
- Replication setup

### Performance Tips
- Enable gzip compression
- Implement caching
- Optimize database queries
- Use CDN for static files
- Monitor server resources

---

**This portal is production-ready and can handle real-world scenarios. Customize as needed for your specific requirements!**
