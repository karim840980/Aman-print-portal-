# 🎫 Ration Card Print Portal - Setup Guide

Complete professional ration card print portal system with admin panel, customer portal, PDF generation, and token-based access.

## 📋 Features

✅ **Customer Portal**
- Search ration card by number
- View all details and family members
- Print history tracking
- Download documents by token
- Request new prints

✅ **Admin Panel**
- Admin login and authentication
- Customer management (add, search, update)
- Print request processing
- PDF generation with ration card details
- Token-based document download
- Dashboard with statistics
- Request approval/rejection workflow

✅ **Technical Stack**
- Frontend: HTML5, CSS3, Vanilla JavaScript
- Backend: Node.js, Express.js
- Database: MongoDB
- PDF: PDFKit
- Authentication: JWT

## 🚀 Installation & Setup

### Prerequisites
- Node.js (v14+)
- MongoDB (local or cloud)
- npm or yarn

### Step 1: Install Dependencies

```bash
cd ration-portal
npm install
```

### Step 2: Setup Environment Variables

Create a `.env` file in root directory:

```env
PORT=5000
MONGODB_URI=mongodb://localhost:27017/ration-portal
JWT_SECRET=your-secret-key-here-change-this
NODE_ENV=development
```

### Step 3: Setup MongoDB

**Local MongoDB:**
```bash
# Windows/Mac/Linux
mongod
```

**Or use MongoDB Atlas (Cloud):**
```env
MONGODB_URI=mongodb+srv://username:password@cluster.mongodb.net/ration-portal
```

### Step 4: Create Admin User (Optional)

Create `createAdmin.js`:

```javascript
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
require('dotenv').config();

const adminSchema = new mongoose.Schema({
  username: String,
  email: String,
  password: String,
  fullName: String,
  role: String,
});

const Admin = mongoose.model('Admin', adminSchema);

async function createAdmin() {
  await mongoose.connect(process.env.MONGODB_URI);
  
  const hashedPassword = await bcrypt.hash('admin123', 10);
  
  const admin = new Admin({
    username: 'admin',
    email: 'admin@rationcard.com',
    password: hashedPassword,
    fullName: 'Admin User',
    role: 'Super Admin',
  });
  
  await admin.save();
  console.log('✅ Admin created: username=admin, password=admin123');
  process.exit();
}

createAdmin();
```

Run it:
```bash
node createAdmin.js
```

### Step 5: Start Server

```bash
npm start
```

Server will run on: `http://localhost:5000`

## 📱 Usage

### Customer Portal
1. Go to http://localhost:5000
2. Click "Customer" tab
3. Enter ration card number
4. View details and print history
5. Request new print or download by token

### Admin Panel
1. Click "Admin" tab
2. Login with credentials (default: admin/admin123)
3. View dashboard statistics
4. Process pending requests
5. Generate PDFs
6. Add/search customers

## 📁 Project Structure

```
ration-portal/
├── server.js                 # Main Express server
├── package.json             # Dependencies
├── .env                      # Environment variables
├── models/
│   └── schemas.js           # Database models
├── routes/
│   ├── auth.js              # Authentication
│   ├── customer.js          # Customer operations
│   ├── admin.js             # Admin operations
│   └── print.js             # PDF generation & download
├── public/
│   ├── index.html           # Frontend HTML
│   ├── styles.css           # Styling
│   └── app.js               # Frontend JavaScript
└── pdfs/                    # Generated PDF storage (auto-created)
```

## 🔐 API Endpoints

### Authentication
```
POST   /api/auth/admin-login          Login admin
POST   /api/auth/register-admin       Register new admin
GET    /api/auth/verify               Verify token
```

### Customer
```
GET    /api/customer/ration/:cardNo   Get customer by ration card
POST   /api/customer/add              Add new customer
GET    /api/customer/search           Search customers
GET    /api/customer/print-history    Get print history
PUT    /api/customer/update/:id       Update customer
```

### Admin
```
POST   /api/admin/create-print-request      Create print request
GET    /api/admin/pending-requests          Get pending requests
GET    /api/admin/request-by-token/:token   Get request by token
PUT    /api/admin/approve-request/:id       Approve request
PUT    /api/admin/reject-request/:id        Reject request
PUT    /api/admin/mark-printed/:id          Mark as printed
PUT    /api/admin/mark-collected/:id        Mark as collected
GET    /api/admin/dashboard-stats           Get statistics
```

### Print
```
POST   /api/print/generate-pdf        Generate PDF
GET    /api/print/download/:token     Download PDF
GET    /api/print/status/:token       Check PDF status
```

## 🎨 Customization

### Change Colors
Edit `public/styles.css` CSS variables:
```css
:root {
  --primary-color: #2c3e50;
  --secondary-color: #3498db;
  --success-color: #27ae60;
  /* ... */
}
```

### Modify PDF Layout
Edit `routes/print.js` in the PDF generation section

### Add New Fields
1. Update schemas in `models/schemas.js`
2. Update forms in `public/index.html`
3. Update API routes

## 🔍 Testing

### Test with Sample Data

**Add sample customer:**
```bash
curl -X POST http://localhost:5000/api/customer/add \
  -H "Content-Type: application/json" \
  -d '{
    "rationCardNumber": "MH-TEST-001",
    "fullName": "Test Customer",
    "fatherName": "Father Name",
    "mobileNumber": "9876543210",
    "address": "Test Address",
    "district": "Mumbai",
    "state": "Maharashtra",
    "pincode": "400001",
    "dateOfBirth": "1990-01-01",
    "gender": "Male"
  }'
```

**Search customer:**
```bash
curl http://localhost:5000/api/customer/search?query=Test
```

## 🐛 Troubleshooting

**MongoDB Connection Error:**
- Make sure MongoDB is running
- Check MONGODB_URI in .env

**CORS Error:**
- Frontend must be on same server or update CORS in server.js

**PDF Not Generating:**
- Check `/pdfs` folder permissions
- Ensure pdfkit is installed

**Port Already in Use:**
```bash
# Change PORT in .env
PORT=3000
```

## 📝 Default Credentials

```
Username: admin
Password: admin123
Email: admin@rationcard.com
```

⚠️ **Change these in production!**

## 🚀 Deployment

### Heroku Deployment

1. Add `Procfile`:
```
web: node server.js
```

2. Push to Heroku:
```bash
git push heroku main
```

### Docker Deployment

Create `Dockerfile`:
```dockerfile
FROM node:16
WORKDIR /app
COPY . .
RUN npm install
EXPOSE 5000
CMD ["npm", "start"]
```

## 📞 Support & Contribution

For issues, improvements, or feature requests, contact support.

---

**Happy coding! 🚀**
